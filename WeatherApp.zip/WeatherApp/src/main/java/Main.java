import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.util.ArrayList;
import java.util.Date;


public class Main {
    private static ArrayList<String> cityCodes = new ArrayList<>();

    public static void main(String[] args) throws Exception {
        extractCityCode();
        createFile();

    }

    private static void callApi() throws Exception {
        StringBuilder jsonContent = new StringBuilder();
        for (String cityCode : cityCodes) {
            String url = "http://api.openweathermap.org/data/2.5/weather?id=" + cityCode + "&appid=" + "2001aa14cc40c2c804d8985d1d008152";
            jsonContent.append("\n").append(new GsonBuilder().setPrettyPrinting().create().toJson(new JsonParser().parse(getHTML(url))));
            jsonContent.append("\n===============================================");
        }
        try (PrintWriter out = new PrintWriter("weatherInfo.txt")) {
            out.println(jsonContent);
        }


    }

    private static void extractCityCode() throws IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONObject a = (JSONObject) parser.parse(new FileReader("cities.json"));
        JSONArray b = (JSONArray) a.get("List");
        for (Object value : b) {
            JSONObject o = (JSONObject) value;
            cityCodes.add(o.get("CityCode").toString());
        }
    }

    public static String getHTML(String urlToRead) throws Exception {
        StringBuilder result = new StringBuilder();
        URL url = new URL(urlToRead);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        //save json response as string
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(conn.getInputStream()))) {
            for (String line; (line = reader.readLine()) != null; ) {
                result.append(line);
            }
        }
        return result.toString();
    }

    public static void createFile() throws Exception {
        File file = new File( "weatherInfo.txt" );
        BasicFileAttributes attrs;
        try {
            attrs = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
            FileTime time = attrs.lastModifiedTime();
            //calculate difference between current time and time weatherInfo file was modified
            long diff = new Date().getTime()- time.toMillis();
            long diffMinutes = diff / (60 * 1000) % 60;
            //file containing info was modified more than 5 minutes ago, so call api again and overwrite file
            if(diffMinutes>5){
                callApi();
            }
            //file doesn't exist if we're entering the catch block, so call api again and write info
        } catch (IOException e) {
            callApi();
        }

        printWeatherInfo();
    }

    private static void printWeatherInfo() throws IOException {
        //print contents of text file to console
        try (BufferedReader br = new BufferedReader(new FileReader("weatherInfo.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        }
    }

}
